# PyCorrCPI
PyCorrCPI - corelation analysis for charged-particle imaging experiments

pip install PyCorrCPI

Find documentation [here](https://htmlpreview.github.io/?https://github.com/f-allum/PyCorrCPI/blob/main/docs/_build/html/index.html)

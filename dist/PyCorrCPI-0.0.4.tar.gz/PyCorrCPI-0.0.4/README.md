# PyCorrCPI
PyCorrCPI - corelation analysis for charged-particle imaging experiments

pip install PyCorrCPI
